/* FILE:    HCTM1638.cpp
   DATE:    21/01/16
   VERSION: 0.1
   AUTHOR:  Andrew Davies
   
   
21/01/16 version 0.1: Original version

Library for TITAN MICRO TM1638 LED driver IC. This Arduino library was written
specifically to support the following Hobby Components product(s):

TM1638 Serial Seven Segment Display & Keypad SKU: HCMODU0095


You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/

#include "Arduino.h"
#include "HCTM1638.h"

/* Constructor to initialise the GPIO and library */
HCTM1638::HCTM1638(byte Strobe_Pin, byte Data_Pin, byte Clock_Pin)
{
	_Strobe = Strobe_Pin;
	_Data = Data_Pin;
	_Clock = Clock_Pin;
	
	/* Set the output pins */
	pinMode(_Strobe, OUTPUT);
	pinMode(_Clock, OUTPUT);
	pinMode(_Data, OUTPUT);
	
	/* Clear the LED display */
	Clear();
}



/* Sets the LED displays brightness where:
   Brightness is the brightness of all LED segments. Valid values are from 0 to 8 */
	
void HCTM1638::Brightness(byte Brightness)
{
	_Brightness = (Brightness & 0x07) | 0x08;
	SendByte(COM_BRIGHTNESS | _Brightness); 
}

/* Turns the display on */
void HCTM1638::Disp_ON(void)
{
	_Brightness |= 0x08;
	SendByte(COM_BRIGHTNESS | _Brightness ); 
}



/* Turns the display off */
void HCTM1638::Disp_OFF(void)
{
	_Brightness &= 0x07;
	SendByte(COM_BRIGHTNESS | _Brightness ); 
}

/* Sends one byte of data to the TM1638 */
void HCTM1638::SendByte(byte Data)
{
	digitalWrite(_Strobe, LOW);
	shiftOut(_Data, _Clock, LSBFIRST, Data);
	digitalWrite(_Strobe, HIGH);
}



/* Clears the LED display */
void HCTM1638::Clear(void)
{
	byte index;
  
	/* Enable address auto increment so we don't have to keep setting 
	   the address for each byte */
	SendByte(COM_AUTO_INC);
	digitalWrite(_Strobe, LOW);
	shiftOut(_Data, _Clock, LSBFIRST, ADD_0);
  
	/* Step through all 16 display memory locations and clear them */
	for(index = 0; index < 16; index++)
	{
		shiftOut(_Data, _Clock, LSBFIRST, 0x00);
	}
	digitalWrite(_Strobe, HIGH);
}



/* Send a byte of data to the display memory where:
   Address is the memory location address. Valid values are from 0x00 to 0x0F 
   
   Data is the byte of data to be written. */
void HCTM1638::WriteDispMem(byte Address, byte Data)
{
	SendByte(COM_SING_ADD);
	digitalWrite(_Strobe, LOW);
	shiftOut(_Data, _Clock, LSBFIRST, ADD_0 | (Address & 0x0F));
	shiftOut(_Data, _Clock, LSBFIRST, Data);
	digitalWrite(_Strobe, HIGH);
}



/* Writes a raw byte of data to one of the 8 seven segments on the TM1638 module
   allowing direct control over each LED segment where:
   
   Digit is the one of the 8 digits on the display. Valid values are from 1 to 8
   
   Value is the raw byte value to write. */
   
void HCTM1638::SetDigit(byte Digit, byte Value)
{
	SendByte(COM_SING_ADD);
	switch(Digit)
	{
		case 1:
			WriteDispMem(DIG_1, Value);
			break;
		case 2:
			WriteDispMem(DIG_2, Value);
			break;
		case 3:
			WriteDispMem(DIG_3, Value);
			break;
		case 4:
			WriteDispMem(DIG_4, Value);
			break;
		case 5:
			WriteDispMem(DIG_5, Value);
			break;
		case 6:
			WriteDispMem(DIG_6, Value);
			break;
		case 7:
			WriteDispMem(DIG_7, Value);
			break;  
		case 8:
			WriteDispMem(DIG_8, Value);
			break;  
	}
}


/* Writes a raw byte of data to one of the 8 LEDs on the TM1638 module
   allowing direct control over LED where:
   
   Led is which LED to control. Valid values are from 1 to 8
   
   Value is the raw byte value to write. A value of 0 will off the LED and a value of 1 will turn it on */
   
void HCTM1638::SetLED(byte Led, byte Value)
{
	switch(Led)
	{
		case 1:
			WriteDispMem(LED_1, Value);
			break;
		case 2:
			WriteDispMem(LED_2, Value);
			break;
		case 3:
			WriteDispMem(LED_3, Value);
			break;
		case 4:
			WriteDispMem(LED_4, Value);
			break;
		case 5:
			WriteDispMem(LED_5, Value);
			break;
		case 6:
			WriteDispMem(LED_6, Value);
			break;
		case 7:
			WriteDispMem(LED_7, Value);
			break;  
		case 8:
			WriteDispMem(LED_8, Value);
			break;
	}
}


/* Returns the current status of the 8 push buttons on the TM1638 module.
   The function returns a byte value representing the combined binary state
   of the 8 buttons. */
byte HCTM1638::ReadButtons(void)
{
	byte index, State;
  
	/* Send command to read button states */
	digitalWrite(_Strobe, LOW);
	shiftOut(_Data, _Clock, LSBFIRST, COM_READ_BUTTONS);
	pinMode(_Data, INPUT);
  
	/* Read the byte state of each button and combine (logical or) them in to one byte */
	State = 0;
	for(index = 0; index < 4; index++)
	{
		State |= shiftIn(_Data, _Clock, LSBFIRST) << index;
	}
  
	pinMode(_Data, OUTPUT);
	digitalWrite(_Strobe, HIGH);
  
	return State;
}


/* Gets the state of one of the 8 push button on the TM1638 module where 
   
   Button is the button to check. Valid values are:
   BUTTON1
   BUTTON2
   BUTTON3
   BUTTON4
   BUTTON5
   BUTTON6
   BUTTON7
   
   Returns a boolean value where false = not pressed and true = pressed*/
   
boolean HCTM1638::ButtonState(byte Button)
{
	byte ButtonStates;
	
	Button &= 0x0f;
	ButtonStates = ReadButtons();
	
	return ButtonStates & (1 << Button);
}


/* Print an alphanumeric string of text to the TM1638 modules seven segment display where:
    
   TextString[] is a null terminated character array of ascii text to display.
   
   Offset is the position on the display to start displaying the text from. Where 1 is the right most and 8 is the left most digit on the display. Text can also be positioned off screen.

   DP is an optional decimal point specifier. If false any decimal points will use one digit of the display. If true decimal points will be displayed on the same digit as the previous alphanumeric character. */
   
void HCTM1638::print7Seg(char TextString[], byte Offset, boolean DP)
{
	unsigned int _StringLength, CharPos, TextStart, TextEnd;
	byte DisPos, Character;
	
	/* Get the length of the text (must be null terminated) */
	_StringLength = strlen(TextString);	

	
	/* Text may be longer than the display so find the start and end position 
	   of the text that will actually appear on the display */
	TextEnd = Offset;
	if (TextEnd >= 8)
	{
		TextStart = TextEnd - 8;
	}else
	{
		TextStart = 0; 
	}
	
	/* Calculate which position on the display the first character of the text
	   will appear */
	DisPos = 9 - (TextEnd - TextStart);
	
	/* Set the pointer to the first character in the character array */
	CharPos = TextStart;
	
	/* Write characters to the display until we either run out of characters or 
	   get to the last digit on the display */
	while(CharPos <= TextEnd && CharPos < _StringLength)
	{
		/* Get the next character from the character array and use the font lookup 
		   array to convert it to the correct seven segment format */ 
		Character = pgm_read_byte_near(&SevenSegChar[TextString[CharPos] - 32]);
		
		/* Check if next character is a numeric decimal point (Not a full stop)
		   and if so then turn on then enable the DP on the current digit. */
		if(CharPos < _StringLength - 1 && DP)
		{
			if(TextString[CharPos + 1] == '.')
			{
				Character = pgm_read_byte_near(&SevenSegChar[TextString[CharPos] - 32]) | 0x80;
				CharPos++;
			}
		}
		
		/* Output the current character to the display */
		SetDigit(DisPos, Character);
		
		/* Move to the next display digit position */
		DisPos++;
		
		/* Move to the next character in the character array */
		CharPos++;
	}
}


/* Prints a signed decimal number to the display where:
   
   Value is the signed floating point number to display
   
   Offset is the position on the display to start displaying the value from. Where 1 is the right most and 8 is the left most digit on the display. Values can also be positioned off screen. 
   
   DecimalPlaces is optional and set number of decimal places to display the number to.*/
   

void HCTM1638::print7Seg(float value, byte Offset, byte DecimalPlaces)
{
	char Buffer[10];
  
	/* Convert the value to an character array */ 
	dtostrf(value, 0, DecimalPlaces, Buffer);
  
	/* Output the array to the display buffer */
	print7Seg(Buffer, Offset, true);
}