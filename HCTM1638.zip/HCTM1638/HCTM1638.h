/* FILE:    HCTM1638.cpp
   DATE:    21/01/16
   VERSION: 0.1
   AUTHOR:  Andrew Davies
   
   
21/01/16 version 0.1: Original version

Library for TITAN MICRO TM1638 LED driver IC. This Arduino library was written
specifically to support the following Hobby Components product(s):

TM1638 Serial Seven Segment Display & Keypad SKU: HCMODU0095

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/

#ifndef HCTM1638_h
#define HCTM1638_h
#include "Arduino.h"

/* TM1638 commands */
#define COM_AUTO_INC 0x40
#define COM_READ_BUTTONS 0x42
#define COM_SING_ADD 0x44
#define COM_BRIGHTNESS 0x80
#define ADD_0 0xC0

/* Module memory address for seven segments */
#define DIG_1 0x00
#define DIG_2 0x02
#define DIG_3 0x04
#define DIG_4 0x06
#define DIG_5 0x08
#define DIG_6 0x0A
#define DIG_7 0x0C
#define DIG_8 0x0E

/* Module Memory locations for LEDs */
#define LED_1 0x01
#define LED_2 0x03
#define LED_3 0x05
#define LED_4 0x07
#define LED_5 0x09
#define LED_6 0x0B
#define LED_7 0x0D
#define LED_8 0x0F


#define BUTTON1 0
#define BUTTON2 1
#define BUTTON3 2
#define BUTTON4 3
#define BUTTON5 4
#define BUTTON6 5
#define BUTTON7 6
#define BUTTON8 7

/* Alphanumeric font for the seven segment display */
const PROGMEM byte SevenSegChar[101] = {0x00, // SPACE
                               0x82, // !
                               0x22, // "
                               0x36, // #
                               0x69, // $
                               0x2D, // %
                               0x7B, // &
                               0x20, // '
                               0x39, // (
                               0x0F, // )
                               0x63, // *
                               0x70, // +
                               0x0C, // ,
                               0x40, // -
                               0x80, // .
                               0x52, // / 
                               0x3F, // 0
                               0x06, // 1
                               0x5B, // 2
                               0x4F, // 3
                               0x66, // 4
                               0x6D, // 5
                               0x7D, // 6
                               0x07, // 7
                               0x7F, // 8        
                               0x6F, // 9
                               0x48, // :
                               0x4C, // ;
                               0x61, // <
                               0x41, // =
                               0x43, // >
                               0x53, // ?
                               0x5F, // @
                               0x77, // A
                               0x7C, // B
                               0x39, // C
                               0x5E, // D
                               0x79, // E
                               0x71, // F
                               0x3D, // G
                               0x76, // H
                               0x06, // I
                               0x0E, // J
                               0x75, // K
                               0x38, // L
                               0x15, // M
                               0x37, // N
                               0x3F, // O
                               0x73, // P
                               0x67, // Q
                               0x33, // R
                               0x6D, // S
                               0x78, // T
                               0x3E, // U
                               0x2E, // V
                               0x2A, // W
                               0x76, // X
                               0x6E, // Y
                               0x4B, // Z
                               0x39, // [
                               0x64, // |
                               0x0F, // ]
                               0x23, // ^
                               0x08, // _ 
                               0x20, // '      
                               0x77, // a
                               0x7C, // b
                               0x39, // c
                               0x5E, // d
                               0x79, // e
                               0x71, // f
                               0x3D, // g
                               0x76, // h
                               0x06, // i
                               0x0E, // j
                               0x75, // k
                               0x38, // l
                               0x15, // m
                               0x37, // n
                               0x3F, // o
                               0x73, // p
                               0x67, // q
                               0x33, // r
                               0x6D, // s
                               0x78, // t
                               0x3E, // u
                               0x2E, // v
                               0x2A, // w
                               0x76, // x
                               0x6E, // y
                               0x4B}; // z   



class HCTM1638
{
	public:
	HCTM1638(byte Strobe_Pin, byte Data_Pin, byte Clock_Pin);	
	void Brightness(byte Brightness);
	void Disp_ON(void);
	void Disp_OFF(void);
	void SendByte(byte Data);
	void Clear(void);
	void WriteDispMem(byte Address, byte Data);
	void SetDigit(byte Digit, byte Value);
	void SetLED(byte Led, byte Value);
	byte ReadButtons(void);
	boolean ButtonState(byte Button);
	void print7Seg(char TextString[], byte Offset, boolean DP = false);
	void print7Seg(float value, byte Offset, byte DecimalPlaces = 0);
	
	private:
	byte _Strobe;
	byte _Data;
	byte _Clock;
	byte _Brightness;
};

#endif